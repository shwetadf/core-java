package com.jlt.pojo;

public class UserMain {

	public static void main(String[] args) {
		
		User user=new User(100);
		System.out.println(user.getUserId());
		
		
		

	}

}
