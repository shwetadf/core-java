package com.jlt.pojo;

public class User {
	
	private int UserId;
	public User()
	{
		System.out.println("Hello");
	}
	
	public User(int UserId)
	{
		System.out.println("");
		this.UserId=UserId;
	}

	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

}
