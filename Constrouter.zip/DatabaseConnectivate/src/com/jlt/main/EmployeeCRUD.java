package com.jlt.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
public class EmployeeCRUD {
	private String url = "jdbc:sqlserver://localhost:1433;database=trainingDB;integratedSecurity=true";
	//private String user = "sa";
	//private String password = "Bahubali@01";
	private String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	int result;
	
	private ArrayList<Employee> employeeList;

	public boolean addEmployee(Employee employee) {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("insert into employee_details values(?,?)");
				preparedStatement.setString(1, employee.getName());
				preparedStatement.setDouble(2, employee.getSalary());

				int rowCount = preparedStatement.executeUpdate();
				if (rowCount > 0)
					return true;
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public ArrayList<Employee> getAllEmployees() {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("select * from employee_details");

				resultSet = preparedStatement.executeQuery();
				employeeList = new ArrayList<Employee>();

				while (resultSet.next()) {
					int employee_id = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");

					Employee employee = new Employee(employee_id, name, salary);
					employeeList.add(employee);

				}
				return employeeList;
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

	public boolean updateEmployeeName(int employeeId, String newName, double newSalary) {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection
						.prepareStatement("update employee_details set name=? , salary = ? where employee_id = ?");
				preparedStatement.setString(1, newName);
				preparedStatement.setDouble(2, newSalary);
				preparedStatement.setInt(3, employeeId);

				int rowCount = preparedStatement.executeUpdate();
				if (rowCount > 0)
					return true;
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public boolean deleteEmployee(int employeeId) {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("delete employee_details where employee_id = ?");
				preparedStatement.setInt(1, employeeId);

				int rowCount = preparedStatement.executeUpdate();
				if (rowCount > 0)
					return true;
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
		return false;
	}

	public Employee getEmployee(int employeeId) {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("select * from employee_details where employee_id = ?");
				preparedStatement.setInt(1, employeeId);

				resultSet = preparedStatement.executeQuery();

				if (resultSet.next()) {
					int employee_id = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");

					Employee employee = new Employee(employeeId, name, salary);
					return employee;
				}
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
		return null;
	}

}
