package com.jlt.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmpolyeeCRUD {
	
	private String url = "jdbc:sqlserver://localhost:1433;database=trainingDB;integratedSecurity=true";
	//private String user = "sa";
	//private String password = "Bahubali@01";
	private String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	
	private Connection connection;
	private PreparedStatement preparedStatement;
	private ResultSet resultSet;
	public void addEmployee() {
		try {
			
			Class.forName(driver);
			connection = DriverManager.getConnection(url);
		 
		if(connection != null) {
			System.out.println("Connection success");
			preparedStatement = connection.prepareStatement("insert into employee_details values(?,?)");
			preparedStatement.setString(1, "Shweta Misal");
			preparedStatement.setDouble(2, 2000);

			int rowCount = preparedStatement.executeUpdate();
			System.out.println("Number of rows inserted :: " + rowCount);
			
		}
		else {
			System.out.println("Connection failed");
		}
			
		} catch (ClassNotFoundException e) {
			
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
			
		} catch (SQLException e) {
			
			System.out.println("Exception!!");
			System.out.println(e.getMessage());
			
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
	
	public void updateEmployee() {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection
						.prepareStatement("update employee_details set name=? , salary = ? where employee_id = ?");
				preparedStatement.setString(1, "Trupti");
				preparedStatement.setDouble(2, 2000);
				preparedStatement.setInt(3, 2);

				int rowCount = preparedStatement.executeUpdate();
				System.out.println("Number of rows updated :: " + rowCount);
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
	public void deleteEmployee() {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("delete employee_details where employee_id = ?");
				preparedStatement.setInt(1, 2);

				int rowCount = preparedStatement.executeUpdate();
				System.out.println("Number of rows deleted :: " + rowCount);
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}

	public void getSingleEmployee() {
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("select * from employee_details where employee_id = ?");
				preparedStatement.setInt(1, 1);

				resultSet = preparedStatement.executeQuery();

				if (resultSet.next()) {
					int employee_id = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");

					System.out.println("Employee Id :: " + employee_id + " Name :: " + name + " Salary :: " + salary);
				}
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
	}
	
	public void getAllEmployee()
	{
		try {

			Class.forName(driver);
			connection = DriverManager.getConnection(url);
			if (connection != null) {
				System.out.println("Connection success");
				preparedStatement = connection.prepareStatement("select * from employee_details");
				

				resultSet = preparedStatement.executeQuery();

				while (resultSet.next()) {
					int employee_id = resultSet.getInt("employee_id");
					String name = resultSet.getString("name");
					double salary = resultSet.getDouble("salary");

					System.out.println("Employee Id :: " + employee_id + " Name :: " + name + " Salary :: " + salary);
				}
			}

		} catch (ClassNotFoundException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} catch (SQLException e) {

			System.out.println("Exception!!");
			System.out.println(e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception!!");
				System.out.println(e.getMessage());
			}
		}
		
	}
	public static void main(String[] args) {
		EmpolyeeCRUD emp=new EmpolyeeCRUD();
		//emp.addEmployee();
		//emp.updateEmployee();
		//emp.deleteEmployee();
		//emp.getSingleEmployee();
		emp.getAllEmployee();
	
		
	
	

	}

}
