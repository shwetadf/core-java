package com.jlt.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCConnectionTest {
	public static void main(String[] args) {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection connection=DriverManager.getConnection(  
					"jdbc:sqlserver://localhost:1433;database=trainingDB;integratedSecurity=true");  
			if(connection != null) {
				System.out.println("Connection success");
				connection.close();
			}
			else {
				System.out.println("Connection failed");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Failed to load driver");
		} catch (SQLException e) {
			System.out.println("SQL Exception");
			System.out.println(e.getMessage());
		}
	}
}
