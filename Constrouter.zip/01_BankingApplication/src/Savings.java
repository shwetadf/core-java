import com.jlt.pojo.Account;

public class Savings extends Account {
	private boolean isSalary;

	
	public Savings(int accountNumber, String name, double balance, boolean isSalary) {
		super(accountNumber, name, balance);
		this.isSalary = isSalary;
		System.out.println("Overloaded Constructor");
	}

	@Override

	// if account is savings then keep 1500 as minimum balance
	// if account is salary the allow 0 balance
	public boolean withdraw(double amount) {
		if (amount > 0 && isSalary && getBalance() - amount >= 0) {
			setBalance(getBalance() - amount);
			return true;
		}
		if (amount > 0 && isSalary == false && getBalance() - amount >= 1500) {
			setBalance(getBalance() - amount);
			return true;
		}
		return false;
	}

	@Override
	public boolean deposit(double amount) {
		if (amount > 0) {
			setBalance(getBalance() + amount);
			return true;
		}
		return false;
	}

}
