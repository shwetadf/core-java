import java.util.Scanner;

public class Saveings {
	public static void main(String[] args) {
		
			// Accept account number , name , balance from user and print account details.
			Scanner scanner = new Scanner(System.in);
			int continueChoice = 0;

			System.out.println("Enter account number");
			int accountNumber = scanner.nextInt();

			System.out.println("Enter Name");
			String name = scanner.next();

			System.out.println("Enter Balance");
			double balance = scanner.nextDouble();

			System.out.println("Do you want to open Salary Account?true or false");
			boolean isSalary = scanner.nextBoolean();

			Savings savings = new Savings(accountNumber, name, balance, isSalary);

			System.out.println("Account Details");
			System.out.println("Account Number = " + savings.getAccountNumber());
			System.out.println("Name = " + savings.getName());
			System.out.println("Balance = " + savings.getBalance());

			do {
				System.out.println("Menu");
				System.out.println("Press 1. Withdraw");
				System.out.println("Press 2. Deposit");
				System.out.println("Press 3. Check Balance");

				System.out.println("Enter your choice");
				int choice = scanner.nextInt();

				switch (choice) {
				case 1:
					System.out.println("Enter amount");
					double amount = scanner.nextDouble();
					boolean result = savings.withdraw(amount);
					if (result == true) {
						System.out.println("Transaction Success");
					} else {
						System.out.println("Transaction Failed");
					}
					break;
				case 2:
					System.out.println("Enter amount");
					amount = scanner.nextDouble();
					if (savings.deposit(amount))
						System.out.println("Transaction Success");
					else
						System.out.println("Transaction Failed");
					break;
				case 3:
					System.out.println("Balance = " + savings.getBalance());
					break;
				default:
					System.out.println("Invalid Choice");
					break;
				}
				System.out.println("Do you want to continue? Press 1 to contine");
				continueChoice = scanner.nextInt();
			} while (continueChoice == 1);

		}
	}