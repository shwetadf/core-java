package com.jlt.main;

import com.jlt.pojo.Account;

public class AccountApplicationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello WOrld");
		
		Account account = new Account(0, null, 0);
//		account.accountNumber = 100;
//		account.name = "Vivek Gohil";
//		account.balance = 1000;
//
//		System.out.println(account.accountNumber);
//		System.out.println(account.name);
//		System.out.println(account.balance);
		
		account.setAccountNumber(100);
		account.setBalance(1000);
		account.setName("shweta");
		
		System.out.println("Account Number = " + account.getAccountNumber());

		;
		System.out.println("Name = " + account.getName());

	
		System.out.println("Balance = " + account.getBalance());

	}

}
