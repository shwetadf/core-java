import java.util.ArrayList;
import java.util.Scanner;
public class EmployeeCRUD {
	private ArrayList<Employee> employeeList = new ArrayList<Employee>();

	public boolean addEmployee(Employee employee) {
		boolean result = employeeList.add(employee);
		return result;
	}

	public ArrayList<Employee> getAllEmployees() {
		return employeeList;
	}

	public boolean updateEmployeeName(int employeeId, String newName) {
		for (Employee employee : employeeList) {
			if (employee.getEmployeeId() == employeeId) {
				employee.setName(newName);
				return true;
			}
		}
		return false;
	}

	public boolean deleteEmployee(int employeeId) {
		for (Employee employee : employeeList) {
			if (employee.getEmployeeId() == employeeId) {
				employeeList.remove(employee);
				return true;
			}
		}
		return false;
	}

	public Employee getEmployee(int employeeId) {
		for (Employee employee : employeeList) {
			if (employee.getEmployeeId() == employeeId) {
				return employee;
			}
		}
		return null;
	}

}
