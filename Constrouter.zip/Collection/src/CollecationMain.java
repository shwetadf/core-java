import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollecationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			System.out.println("1.ArrayList :: Implements List interface");
			ArrayList<String> nameList = new ArrayList<String>();
			System.out.println("Size of list :: " + nameList.size());
			nameList.add("Jyoti");
			nameList.add("Nikhil");
			nameList.add("Akshay");
			nameList.add("Jyoti");
			nameList.add("Akshay");
			System.out.println("Size of list :: " + nameList.size());
			System.out.println(nameList);
			for (String name : nameList) {
				System.out.println(name);
			}

			System.out.println("----------------------------------");
			System.out.println("2.HashSet :: Implements Set interface");
			HashSet<Integer> numberSet = new HashSet<Integer>();
			System.out.println("Size of Set :: " + numberSet.size());
			numberSet.add(1008);
			numberSet.add(10);
			numberSet.add(1);
			numberSet.add(9);
			numberSet.add(44);
			numberSet.add(1);
			numberSet.add(44);
			numberSet.add(10);
			numberSet.add(1008);
			System.out.println("Size of Set :: " + numberSet.size());
			System.out.println(numberSet);
			System.out.println("----------------------------------");
			System.out.println("3.TreeSet :: Implements SortedSet interface");
			TreeSet<Integer> numberTreeSet = new TreeSet<Integer>();
			System.out.println("Size of treeset :: " + numberTreeSet.size());
			numberTreeSet.add(1008);
			numberTreeSet.add(10);
			numberTreeSet.add(1);
			numberTreeSet.add(9);
			numberTreeSet.add(44);
			numberTreeSet.add(1);
			//System.out.println("Size of userMap :: " + userMap.size());
			numberTreeSet.add(44);
			numberTreeSet.add(10);
			numberTreeSet.add(1008);
			System.out.println("Size of treeset :: " + numberTreeSet.size());
			System.out.println(numberTreeSet);
			System.out.println("----------------------------------");
			System.out.println("4.HashMap :: Implements Map interface");
			HashMap<Integer, String> userMap = new HashMap<Integer, String>();
			userMap.put(143, "Vivek");
			userMap.put(11, "Jyoti");
			userMap.put(2, "Nikhil");
			userMap.put(7649, "Akshay");
			userMap.put(76, "Akshay");
			userMap.put(2, "Tejas");
			System.out.println("Size of userMap :: " + userMap.size());
			System.out.println(userMap);
			System.out.println("----------------------------------");
			System.out.println("5.TreeMap :: Implents SortedMap interface");
			TreeMap<Integer, String> userTreeMap = new TreeMap<Integer, String>();
			System.out.println("Size of userTreeMap :: " + userTreeMap.size());
			userTreeMap.put(143, "Vivek");
			userTreeMap.put(11, "Jyoti");
			userTreeMap.put(2, "Nikhil");
			userTreeMap.put(7649, "Akshay");
			userTreeMap.put(76, "Akshay");
			userTreeMap.put(2, "Tejas");
			System.out.println("Size of userMap :: " + userTreeMap.size());
			System.out.println(userTreeMap);
		}


}
