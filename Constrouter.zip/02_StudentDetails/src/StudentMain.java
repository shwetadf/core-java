import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter admno number");
		int admno = scanner.nextInt();

		System.out.println("Enter Name");
		String sname = scanner.next();

		System.out.println("Enter eng marks");
		int eng = scanner.nextInt();
		System.out.println("Enter math marks");
		int math = scanner.nextInt();
		System.out.println("Enter sci marks");
		int sci = scanner.nextInt();
		
		Student student=new Student();
		student.setAdmno(admno);
		student.setSname(sname);
		student.setEng(eng);
		student.setMath(math);
		student.setSci(sci);
		System.out.println("Student Details");
		System.out.println("admno = " + student.getAdmno());
		System.out.println("Name = " + student.getSname());
		System.out.println("marks = " +student.getEng());
		System.out.println("marks = " +student.getMath());
		System.out.println("marks = " +student.getSci());
		System.out.println("Total = " +student.getTotal());
		
		

	}

}
