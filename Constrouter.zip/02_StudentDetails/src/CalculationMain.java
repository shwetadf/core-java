
public class CalculationMain {
	public static void main(String[] args) {
		Calculation calculation = new Calculation();
		calculation.accept();
		calculation.calculate();
		calculation.display();
	}
}
