
public class B {

	public void show() {
		System.out.println("Hello");
	}

}
